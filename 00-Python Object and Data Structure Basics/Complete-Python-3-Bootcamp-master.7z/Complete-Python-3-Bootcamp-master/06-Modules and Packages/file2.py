import file1
file1.list1.append(12)
print(file1.list1)