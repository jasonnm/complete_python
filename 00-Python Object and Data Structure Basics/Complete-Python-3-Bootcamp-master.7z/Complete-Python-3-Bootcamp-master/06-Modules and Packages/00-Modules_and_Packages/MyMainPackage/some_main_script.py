def report_main():
	print("Hey I am in some_main_script in main package.")